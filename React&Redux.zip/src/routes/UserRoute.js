import React from 'react'
import {Route} from 'react-router-dom'

function UserRoute(props){
    return <Route {...props}/>
}

export default UserRoute