import {INCR_MENT} from '../helper/actionTypes'

export function timerReducer(state=0,action){

    switch (action.type) {
        case INCR_MENT:
            return state+1
        
        default:
            return state    
    }
}