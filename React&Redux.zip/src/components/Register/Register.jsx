import React, {Component} from 'react'
import {Link} from 'react-router-dom'
class Register extends Component {
    render(){

        return (
            <div>
            <p>Register Works</p>
            <Link to="/login" className="btn btn-link float-right">Back to Home</Link>
            </div>
        )
    }

}

export default Register