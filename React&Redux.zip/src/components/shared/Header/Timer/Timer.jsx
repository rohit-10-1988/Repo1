import React, {Component} from 'react'
import {connect} from 'react-redux'
import {incrTimer} from '../../../../actions/timeraction'
class Timer extends Component {

    componentDidMount(){
        setInterval(() => this.props.incr(), 1000)
    }
    render(){
        return <span>{this.props.timer}</span>
    }
}

function mapStateToProps(state){
    return{
        timer: state.timer
    }
}

function mapDispatchToProps(dispatch){
    return{
        incr: () => dispatch(incrTimer())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Timer)