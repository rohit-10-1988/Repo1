import React from 'react';
import {Link} from 'react-router-dom'
import {connect} from 'react-redux'
import {user_logged_out} from '../../../actions/userActions'
import Timer from './Timer/Timer'
function Header(props){
    const {user} = props
    return (
        <div className="mt-3">
            <h1>Task Manager</h1>
            <hr />
            {
                user && <Timer />
            }
            {
                user && (
                    <div>
                        <Link className="btn btn-danger float-right" onClick={() => props.logout()} to="/">Logout</Link>
                        <div className="clearfix"></div>
                        <hr />
                    </div>
                )
            }
         
              
        </div>
    )
}

function mapState(state){
    return{
        user: state.user
    }
}

function mapDispatchToProps(dispatch){
    return{
        logout:()=> dispatch(user_logged_out())
    }
}

export default connect(mapState,mapDispatchToProps)(Header)