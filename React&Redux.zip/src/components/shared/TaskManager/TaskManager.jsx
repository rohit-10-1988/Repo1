import React from 'react';
import {Row, Col} from 'reactstrap';

import TaskForm from './TaskForm/TaskForm.jsx';
import TaskList from './TaskList/TaskList.jsx';


class TaskManager extends React.Component {

   
    render(){
        
        return(
            <Row>
               <Col> 
    
                <Row>
                    <Col>
                        <TaskForm />
                    </Col>
                    <Col>
                        <TaskList />
                    </Col>
                </Row>
                </Col>
           </Row> 
        )

    }

}


export default TaskManager