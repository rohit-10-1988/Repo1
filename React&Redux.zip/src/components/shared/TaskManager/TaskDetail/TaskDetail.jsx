import React, {Component} from 'react';
import {Alert, Card, CardHeader, CardBody} from 'reactstrap';
import {Link} from 'react-router-dom'
import {API_URL} from '../../../../config/api'
import axios from 'axios'
class TaskDetail extends Component{

    state = {
        task:null
    }

    componentDidMount(){
        
        const {id} = this.props.match.params
        axios.get(API_URL + '/' + id)
                .then((res) => this.setState({task: res.data}))
                
    }
    render(){

        const{task} = this.state;

        if(!task){
            return <Alert color="info">No Task Found</Alert>
        }
        return(
            <Card>
                <CardHeader>
                    {task.title}
                </CardHeader>
                <CardBody>
                    {task.description}
                    <p>
                        <Link to="/tasks">Back To Task</Link>
                    </p>
                    
                </CardBody>
            </Card>
        )
    }
}

export default TaskDetail