import React from 'react';
import { Button, Form, FormGroup, Label, Input } from 'reactstrap';
import { connect } from 'react-redux'
import {addTaskAction} from '../../../../actions/taskActions'
class TaskForm extends React.Component{

    state = {

        title : '',
        description : ''
    }

    constructor(props){
        super(props)
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

        handleSubmit(e){
            e.preventDefault();
            console.log(this)
            const{title, description} = this.state;
            let valid =true;

            if(title === ''){
                this.setState({
                    titleErr: 'Title can not be blank'
                })

                valid = false
            }

            if(description === ''){
                this.setState({
                    descriptionErr: 'Description can not be blank'
                })

                valid = false
            }

            if(valid){
                const data = {
                    title, description

                }
                this.props.add(data)
                this.setState({
                    title : '',
                    description : '',
                    titleErr:'',
                    descriptionErr:''
                })
            }
        }

        handleChange(e){
        
            let err = e.target.name + 'Err'
            this.setState({
                [e.target.name]: e.target.value,
                [err]:''
            })

            }

        

        render(){
            const {titleErr, title, description, descriptionErr} = this.state
            return (
                <Form onSubmit = {this.handleSubmit}>
                    <FormGroup>
                        <Label htmlFor="title">Title</Label>
                        <Input id="title" name ="title" value = {title} onChange={this.handleChange} />
                        <span id="titleErr">{titleErr}</span>
                    </FormGroup>
        
                    <FormGroup>
                        <Label htmlFor="description">Description</Label>
                        <Input type="textarea" name ="description" value = {description} id="description" rows="5" onChange={this.handleChange} />
                        <span id="descriptionErr">{descriptionErr}</span>
                    </FormGroup>
        
                    <Button color="primary">Add</Button>
                </Form>
            )


        }
    }

    function dispatchToprops(dispatch){

        return {
            add:(data) =>{
                dispatch(addTaskAction(data));
            }

        }
    }


export default connect(null, dispatchToprops) (TaskForm)