import React from 'react';
import {ListGroupItem,Button} from 'reactstrap';
import {connect} from 'react-redux';
import {removeTaskAction} from '../../../../../actions/taskActions'
import {Link} from 'react-router-dom'
function TaskItem(props){
    
    const {task} = props

    function handleDel(){

        props.remove(task.id)
    }


    return (

        <ListGroupItem>
            
            <Link to={'/tasks/' + task.id}>{task.title}-{task.seq}/{task.total}</Link>
            {/* {task.description} */}
            <Button close onClick={handleDel}/>
        </ListGroupItem>
    )
}

function dispatchtoprops(dispatch){

    return{
        remove: (id) => { 
            dispatch(removeTaskAction(id));
        }

    }

}

export default connect(null, dispatchtoprops) (TaskItem)