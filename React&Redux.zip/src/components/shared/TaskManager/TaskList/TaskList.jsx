import  React,{Component} from 'react';
import {Alert, ListGroup} from 'reactstrap';
import TaskItem from './TaskItem/TaskItem.jsx';
import { connect } from 'react-redux'
import {getTaskAction} from '../../../../actions/taskActions'
import {createSelector} from 'reselect'
class TaskList extends Component{

    componentDidMount(){

        this.props.getTasks()
    }

    render(){
        const {tasks} = this.props
        console.log('render')
        const tasklist = tasks.map((task) => {
    
            return <TaskItem key = {task.id} task={task} />
        });
    
        if(tasks.length === 0){
    
            return <Alert>No to Display</Alert>
        }
       
        return (
    
            <ListGroup>
                {tasklist}
            </ListGroup>
        )

    }

}

const taskSelector = createSelector(
    state => state.tasks,
    function(tasks){
        return tasks.map((task, i)=>{
            task.total = tasks.length;
            task.seq = i+1;
            return task
        })
    }
)

function mapStateToProps(state){
    return {
      tasks: taskSelector(state)

    }

}

function mapDispatchToProps(dispatch){
    return{
        getTasks: () => {
            dispatch(getTaskAction())
        }
    }

}

export default connect(mapStateToProps,mapDispatchToProps) (TaskList)