import React from 'react';


function Footer(props){

    return (
        <div>
            <hr />
            <small>&copy; Edureka!</small>
        </div>
    )
}


export default Footer