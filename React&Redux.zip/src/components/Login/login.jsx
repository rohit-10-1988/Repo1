import React, {Component} from 'react'
import { Row,Col,Form, FormGroup, Label, Input, FormFeedback, Button} from 'reactstrap'
import {connect} from 'react-redux'
import {Link} from 'react-router-dom'
import {user_logged_In} from '../../actions/userActions'
class Login extends Component{

    state = {
        data:{
            username:'',
            password:''
        },
        errors:{}

    }

    handleChange = (e) => {
        this.setState({
            data:{
                ...this.state.data,
                [e.target.name] : e.target.value
            },
            errors:{
                ...this.state.errors,
                [e.target.name]:''
            }
            
        })
    }
    validate = () =>{
        const {data} = this.state
        let errors = {}

        if(data.username === '') errors.username = 'Username cannot be blank'
        if(data.password === '') errors.password = 'password cannot be blank'

        return errors;
    }

    getIntialstate = () =>({
        data:{
            username: '',
            password: ''
        },
        errors:{}
    })

    handleSubmit = (e) => {
        e.preventDefault()
        const {data} = this.state;
        const errors = this.validate();
        if(Object.keys(errors).length === 0){

                this.setState(this.getIntialstate)
                if(data.username==="admin" && data.password ==="admin"){
                    this.props.userLoggedIn(data.username);
                   this.props.history.push('/tasks');
                }
           
        }else{
            this.setState({

              errors  
            })
        }
       
    }


    render(){
        const {errors,data} = this.state
       return (
        <Row>
            <Col md={4}>
            <Form onSubmit={this.handleSubmit}>
                <FormGroup>
                    <Label for="username">UserName</Label>
                    <Input id="username" name="username" value = {data.username} invalid={!!errors.username} onChange = {this.handleChange}/>
                    <FormFeedback>{errors.username}</FormFeedback>
                </FormGroup>

                <FormGroup>
                    <Label for="password">Password</Label>
                    <Input id="password" name="password" value = {data.password} invalid={!!errors.password} onChange = {this.handleChange}/>
                    <FormFeedback>{errors.password}</FormFeedback>
                </FormGroup>
            <Button class="primary">Login</Button>
            <Link to="/register" className="btn btn-link float-right">Register</Link>
            </Form>
            </Col>
        </Row>


       )
    }

}

function mapDispatchToProps(dispatch){
    return{
        userLoggedIn: (user) => {
            dispatch(user_logged_In(user))
        }
    }
}

export default connect(null, mapDispatchToProps)(Login)