import { createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import rootReducer from './reducers'
import logger from 'redux-logger'
import { user_logged_In } from './actions/userActions';

const store = createStore(rootReducer, applyMiddleware(thunk));

if(localStorage.getItem('user')){
    store.dispatch(user_logged_In(localStorage.getItem('user')))
}

export default store