import {USER_LOGGED_IN, USER_LOGGED_OUT} from '../helper/actionTypes'

export function user_logged_In(user){
    localStorage.setItem('user', user)
    return{
        type: USER_LOGGED_IN,
        user
    }

}

export function user_logged_out(){
    localStorage.removeItem('user')
    return{
        type: USER_LOGGED_OUT
    }

}