import { ADD_TASK, REMOVE_TASK, TASK_LOADED } from '../helper/actionTypes'
import Axios from 'axios'
import {API_URL} from '../config/api'


export function getTaskAction(){
    return (dispatch) => {
        Axios.get(API_URL)
        .then(res => {
            console.log(res.data)
            dispatch(taskLoaded(res.data));
        })
    }
}

export function taskLoaded(tasks){
    return{

        type:TASK_LOADED,
        tasks
    }
    

}

export function addTaskAction(data){
    data.completed = true;
    data.date = new Date();
    return(dispatch) => {
        Axios.post(API_URL, data)
            .then(res => {
                dispatch(taskAdded(res.data))
            });
    }

}

export function taskAdded(task){
    return{

        type: ADD_TASK,
        task

    }
 
}

export function removeTaskAction(id){

    return(dispatch) => {
        Axios.delete(API_URL + '/' + id)
            .then(() => {
                dispatch(taskDeleted(id))
            });
    }
}

export function taskDeleted(id){

    return{

        type :REMOVE_TASK,
        id
    }
}