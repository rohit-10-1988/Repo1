import {INCR_MENT} from '../helper/actionTypes'

export function incrTimer(){
    return{
        type: INCR_MENT
    }
}