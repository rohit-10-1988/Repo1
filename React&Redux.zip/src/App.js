import React from 'react';

import {Route, Switch} from 'react-router-dom';
import Header from './components/shared/Header/Header.jsx';
import Footer from './components/shared/Footer/footer.jsx';
import Login from './components/Login/login.jsx';
import Register from './components/Register/Register.jsx';
import TaskManager from './components/shared/TaskManager/TaskManager.jsx';
import PageNotFound from './components/shared/PageNotFound/PageNotFound.jsx';
import TaskDetail from './components/shared/TaskManager/TaskDetail/TaskDetail.jsx';
import UserRoute from './routes/UserRoute';
function App() {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <Header />
        </div>  
      </div>

      <div className="row">
        <div className="col">
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/login" component={Login} />
          <Route path="/Register" component={Register} />
          <UserRoute path="/tasks" exact component={TaskManager} />
          <UserRoute path="/tasks/:id" component={TaskDetail} />
          <Route path="**" component={PageNotFound} />
        </Switch>
        
        </div>  
      </div>

      <div className="row">
        <div className="col">
        <Footer />
        </div>  
      </div>
      
      
    </div>
  );
}

export default App;
