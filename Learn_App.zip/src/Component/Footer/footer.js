import React from 'react';
import cssStyleClassName from './footer.module.css';
import { Link } from 'react-router-dom';
import {CURRENT_YEAR} from '../../config';
function Footer(){

    return(
        <div className={cssStyleClassName.footer}>
            <Link to="/" className={cssStyleClassName.logo}>
            <img alt="nba logo" src="/images/nba_logo.png" />
            </Link>
            <div className={cssStyleClassName.right}>
                @NBA {CURRENT_YEAR} All rights Reserved
            </div>
        </div>
    )
}

export default Footer;