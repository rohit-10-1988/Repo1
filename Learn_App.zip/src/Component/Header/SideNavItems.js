import React from 'react';
import cssStyleClassName from './header.module.css';
import { Link } from 'react-router-dom';
import FontAwesome from 'react-fontawesome';


function SideItems(){

    const Items = [
        {
            type: cssStyleClassName.option,
            icon: 'home',
            text: 'Home',
            link: '/'
        },
        {
            type: cssStyleClassName.option,
            icon: 'file-text-o',
            text: 'News',
            link: '/news'
        },
        {
            type: cssStyleClassName.option,
            icon: 'play',
            text: 'Videos',
            link: '/videos'
        },
        {
            type: cssStyleClassName.option,
            icon: 'sign-in',
            text: 'Sign in',
            link: '/sign-in'
        },
        {
            type: cssStyleClassName.option,
            icon: 'sign-out',
            text: 'Sign out',
            link: '/sign-out'
        }
    ]

    function showItems(){
        return Items.map((item,i)=>{
            return(
                <div key={i} className={item.type}>
                <Link to={item.link}>
                    <FontAwesome name={item.icon} />
                    {item.text}
                </Link>
            </div>
            )
        })
    }

        return(
            <div>
                {showItems()}
            </div>
         )

}

export default SideItems;