import React from 'react';
import {Link} from 'react-router-dom';
import cssStyleClassName from './videos.module.css';
import Cardinfo from '../News_list/cardinfo';
function VideoTemplate(props){
    return props.data.map((item,i)=>{
        return <Link to={`/videos/${item.id}`} key={i}>
                    <div className={cssStyleClassName.video_wrap}>
                        <div className={cssStyleClassName.left}
                             style={{
                                 background:`url(/images/videos/${item.image})`
                             }}
                        >
                            <div></div>
                        </div>
                        <div className={cssStyleClassName.right}>
                        <Cardinfo teams={props.teams} team={item.team} date={item.date} />
                            <h2> {item.title}</h2>
                        </div>
                    </div>
               </Link>
    });
}

export default VideoTemplate