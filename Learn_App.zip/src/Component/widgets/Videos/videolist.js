import React, {Component} from 'react';
import axios from 'axios';
import {URL} from '../../../config';
import Button from '../Button/button';
import cssStyleClassName from './videos.module.css';
import VideoTemplate from '../Videos/Videostemplate';
class VideoList extends Component{
    state={
        teams:[],
        videos:[],
        start:this.props.start,
        end:this.props.start + this.props.amount,
        amount:this.props.amount
    }

    rendertitle = (title)=>{
        return title ? 
        <h3><strong>NBA</strong>Videos</h3>
        : null;
    }

    componentWillMount(){
        this.request(this.state.start,this.state.end)

    }

    request = (start,end)=>{

        if(this.state.teams.length<1){
            axios.get(`${URL}/teams`)
            .then(res => {
                this.setState({
                    teams:res.data
                })
            })
        }
        axios.get(`${URL}/videos?_start=${start}&_end=${end}`)
        .then((res)=>{

            this.setState({
                videos:[...this.state.videos,...res.data],
                start,
                end
            })
        })
    }
    renderVideos=()=>{
        let template = null;
        switch(this.props.type){
            case('card'):
                template = <VideoTemplate  data={this.state.videos} teams={this.state.teams}/>
                break;
            default:
                template = null;    

        }
        return template;
    }
    loadMore = () =>{
        let end = this.state.end + this.state.amount;
        this.request(this.state.end,end)
    }
    renderButton = (button) =>{
        return button ?  
        <Button type="loadMore" cta="Load More Videos" loadMore={()=>this.loadMore()}/>
        : <Button type="linkTo" cta="More Videos" linkTo="/videos/"/>;
    }

    render(){
        console.log(this.state.videos)
        return(
            <div>
            <div className={cssStyleClassName.videosList}>
               {this.rendertitle(this.props.title)}
               
            </div>
            {this.renderVideos()}
            {this.renderButton(this.props.loadmore)}
            </div>
        )
    }
}

export default VideoList;