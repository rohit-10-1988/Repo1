import React from 'react';
import {Link} from 'react-router-dom';
import cssStyleClassName from './button.module.css';

function Button(props){
    let template = null;
    switch(props.type){

        case('loadMore'):
            template = (
                <div className={cssStyleClassName.button}
                    onClick={props.loadMore}
                >
                    {props.cta}
                </div>
            )
            break;
        case('linkTo'):  
            template = (
                <Link to={props.linkTo}>
                    <div className={cssStyleClassName.button}>
                        {props.cta}
                    </div>
                </Link>
            )
            break;  
        default:
            template = null;    
    }
    return template;
}

export default Button;