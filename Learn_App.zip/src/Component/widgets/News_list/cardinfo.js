import React from 'react';
import FontAwesome from 'react-fontawesome';
import cssStyleClassName from './News_list.module.css';

function Cardinfo(props){

    function teamName(teams,team){
        let data = teams.find((item)=>{

            return item.id===team;
        });
        if(data){
            return data.name;
        }
    }

    return(
        <div className={cssStyleClassName.card}>
           <span className={cssStyleClassName.team}>
                {teamName(props.teams,props.team)}
           </span>
           <span className={cssStyleClassName.date}>
                <FontAwesome name="clock-o"/>
                {props.date}
           </span>
        </div>
    )
}

export default Cardinfo;