import React, {Component} from 'react';
import axios from 'axios';
import {CSSTransition,TransitionGroup} from 'react-transition-group';
import {Link} from 'react-router-dom';
import cssStyleClassName from './News_list.module.css';
import {URL} from '../../../config';
import Button from '../Button/button';
import Cardinfo from '../News_list/cardinfo';
class NewsList extends Component{
    
    state={
        teams:[],
        items:[],
        start:this.props.start,
        end:this.props.start + this.props.amount,
        amount:this.props.amount
    }
    
    componentWillMount(){
        this.request(this.state.start,this.state.end)

    }

    request = (start,end)=>{

        if(this.state.teams.length<1){
            axios.get(`${URL}/teams`)
            .then(res => {
                this.setState({
                    teams:res.data
                })
            })
        }
        axios.get(`${URL}/articles?_start=${start}&_end=${end}`)
        .then((res)=>{

            this.setState({
                items:[...this.state.items,...res.data],
                start,
                end
            })
        })
    }

    loadMore = () =>{
        let end = this.state.end + this.state.amount;
        this.request(this.state.end,end)
    }

    renderNews = (type) => {
        let template = null;
        
        switch(type){
            
            case('card'):
            template = this.state.items.map((item,i)=>{
                    return(
                        <CSSTransition
                        classNames={{
                            enter: cssStyleClassName.newslist_wrap,
                            enterActive: cssStyleClassName.newslist_wrap_1
                        }}
                        timeout={500}
                        key={i}
                        >
                            <div key={i}>
                                <div className={cssStyleClassName.news_list}>
                                    <Link to={`/articles/${item.id}`}>
                                        <Cardinfo teams={this.state.teams} team={item.team} date={item.date} />
                                       <h2>{item.title}</h2>
                                    </Link>
                                </div>
                            </div>
                        </CSSTransition>

                    )
            })
                break;
            default:
                template = null;    
        }
        return template;

    }

    render(){
        
        return(
            <div>
                <TransitionGroup
                component="div"
                className="list"
                >
                  {this.renderNews(this.props.type)}
                </TransitionGroup>
                <Button 
                type="loadMore"
                loadMore={()=>this.loadMore()}
                cta="Load More News"
                />
            
            </div>
        )
    }

}
export default NewsList;