import React, {Component} from 'react';
import './layout.css';
import Header from '../Component/Header/Header';
import Footer from '../Component/Footer/footer';

class Layout extends Component{

    state = {
        showNav:false
    }

    toggleNav(action){
        this.setState({
            showNav:action
        })
    }

    render(){
        return(
        <div>
            <Header
            showNav={this.state.showNav}
            onHideNav={()=>this.toggleNav(false)}
            onOpenNav={()=>this.toggleNav(true)}
            />
            {this.props.children}
            <Footer />
        </div>

        )
    }
}

export default Layout;
